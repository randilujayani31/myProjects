package com.example.lms_5066;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void bookDetails(View view) {
        startActivity(new Intent(MainActivity.this, book.class));
    }

    public void bookCopyDetails(View view) {
        startActivity(new Intent(MainActivity.this, bookCopy.class));
    }

    public void memberDetails(View view) {
        startActivity(new Intent(MainActivity.this, member.class));
    }

    public void publisherDetails(View view) {
        startActivity(new Intent(MainActivity.this, publisher.class));
    }

    public void authorDetails(View view) {
        startActivity(new Intent(MainActivity.this, bookAuthor.class));
    }


    public void lendingDetails(View view) {
        startActivity(new Intent(MainActivity.this, bookLoan.class));
    }

    public void branchDetails(View view) {
        startActivity(new Intent(MainActivity.this, branch.class));
    }
}
